DISPLAY_NAME= .gg/vendinha TICKET
DESCRIPTION= .gg/vendinha TICKET
MAIN=index.js
MEMORY=256
VERSION=recommended