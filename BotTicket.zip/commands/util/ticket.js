const Discord = require("discord.js")
const config = require("../../config.json")

module.exports = {

    name: "ticket",
    description: "Ticket",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client ,interaction, args) => {
        if (!interaction.member.permissions.has("MANAGE_MESSAGES")) {
            interaction.reply({ content: `Você não possui permissão para utilizar este comando. 🔴`, ephemeral: true })
    } else {
        const emebd_tickets = new Discord.EmbedBuilder()
        .setColor(config.cor)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true}))
        .setDescription("**🤖 Central** \n >   **Bem vindo(a), a aba de central de atendimento, para fornecer um orçamento personalizado para os nossos serviços, clique abaixo e diga oque você precisa atualmente do atendimento.**")
		.setImage('https://media.discordapp.net/attachments/1199870408111964281/1199871957269758042/banner_2.png?ex=65c41ed7&is=65b1a9d7&hm=87b02ba69877f4cdd8c86450a6006e842c320de0a9a4ed2f032f0a627c115fcf&=&format=webp&quality=lossless')
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }), })
        .setAuthor({ name: `${interaction.guild.name} - Atendimento`, iconURL: interaction.guild.iconURL({ dynamic: true}) })
        const botao = new Discord.ButtonBuilder()
        .setLabel("📨 Abrir Ticket")
        .setCustomId('butons')
        .setStyle("Primary")
        const row = new Discord.ActionRowBuilder().addComponents(botao);
        interaction.channel.send({ embeds: [emebd_tickets], components: [row] })
        interaction.delete()
        }
  }
}