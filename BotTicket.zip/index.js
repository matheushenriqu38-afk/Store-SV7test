const Discord = require("discord.js");
const client = new Discord.Client({ intents: [1, 512, 32768, 2, 128] });
const config = require("./config.json");
const fs = require("fs");
const { QuickDB } = require ("quick.db");
const db = new QuickDB()
const transcript = require('discord-html-transcripts')



client.login(config.token)

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
client.categories = fs.readdirSync(`./commands/`);

fs.readdirSync('./commands/').forEach(local => {
    const comandos = fs.readdirSync(`./commands/${local}`).filter(arquivo => arquivo.endsWith('.js'))

    for(let file of comandos) {
        let puxar= require(`./commands/${local}/${file}`)

        if(puxar.name) {
            client.commands.set(puxar.name, puxar)
        } 
        if(puxar.aliases && Array.isArray(puxar.aliases))
        puxar.aliases.forEach(x => client.aliases.set(x, puxar.name))
    } 
});

client.on("messageCreate", async (message) => {

    let prefix = config.prefix;
  
    if (message.author.bot) return;
    if (message.channel.type === Discord.ChannelType.DM) 
    return;     
  
    if (!message.content.toLowerCase().startsWith(prefix.toLowerCase())) return;
  
    if(!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
  
    let cmd = args.shift().toLowerCase()
    if(cmd.length === 0) return;
    let command = client.commands.get(cmd)
    if(!command) command = client.commands.get(client.aliases.get(cmd)) 
    
  try {
      command.run(client, message, args)
  } catch (err) { 
     console.error('Erro:' + err); 
  }
});

client.on("ready", () => {
console.clear()
console.log("░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓███████▓▒░░▒▓███████▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░ ")
console.log("░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░")
console.log(" ░▒▓█▓▒▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░")
console.log(" ░▒▓█▓▒▒▓█▓▒░░▒▓██████▓▒░ ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓████████▓▒░")
console.log("  ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░")
console.log("  ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░")
console.log("   ░▒▓██▓▒░  ░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░")                   
});
////////////////////
//                                                                INICIO DO BOT 
////////////////

////////////////////
//                                                                STATUS - BOT
////////////////
client.on("ready", (member) => {

    const activities = [
      { name: `.gg/vendinha`, type: 1, url: 'https://www.twitch.tv/discord'},
    ];
    
    
    const status = [
      'dnd'
    ];
    
    let i = 0;
    setInterval(() => {
      if(i >= activities.length) i = 0
      client.user.setActivity(activities[i])
      i++;
    }, 5 * 500);
    
    let s = 0;
  });

////////////////////
//                                                              ENVIAR BOTOES TICKET
///////////////////

client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton() && interaction.customId === "butons") {
      const painel = new Discord.ActionRowBuilder().addComponents(
          new Discord.SelectMenuBuilder()
              .setCustomId("painel_ticket")
              .setPlaceholder("Escolha o Assunto do Ticket")
              .addOptions([
                  {
                      label: "📞 Suporte",
                      description: "Clique aqui caso esteja com problemas com o produto.",
                      value: "opc3"
                  },
                  {
                      label: "🛒 Resgatar Produto",
                      description: "Clique aqui para receber seu produto.",
                      value: "opc2"
                  },
                  {
                      label: "🔍 Dúvidas",
                      description: "Clique aqui caso esteja com dúvidas.",
                      value: "opc1"
                  },
              ])
      );

      interaction.reply({ components: [painel], ephemeral: true });
      setTimeout(() => interaction.deleteReply(), 7000);
  }
});


////////////////////
//                                                                 TICKET
////////////////

client.on("interactionCreate", async (interaction) => {
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId === "painel_ticket") {
      let opc = interaction.values[0]
      if (opc === "opc1") {
        let nome = `📩・${interaction.user.username}`;
        if (interaction.guild.channels.cache.find(c => c.name === nome)) {
          interaction.reply({ content: `❌ Você já possui um ticket aberto em ${interaction.guild.channels.cache.find(c => c.name === nome)}!`, ephemeral: true })
        } else {
          interaction.guild.channels.create({
            name: nome,
            type: Discord.ChannelType.GuildText,
            parent: '1199871663605551155',
            permissionOverwrites: [
              {
                id: interaction.guild.id,
                deny: [
                  Discord.PermissionFlagsBits.ViewChannel
                ]

              },
              {
                id: interaction.user.id,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]

              },
              {
                id:  config.cargo_ticket,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]
              }
            ]
          }).then(async (ch) => {
              const ir = new Discord.ButtonBuilder()
              .setEmoji('🔗')
              .setLabel('Ir Para o Ticket')
              .setStyle(5)
              .setURL(`https://discord.com/channels/${interaction.guild.id}/${ch.id}`);
  
            const linkqn = new Discord.ActionRowBuilder().addComponents(ir);
  
            interaction.reply({ components: [linkqn], content: `${interaction.user} Para Acessar seu Ticket Basta Clicar Abaixo`, ephemeral: true});
            await db.set(`quemabriu_${interaction.guild.id}`, interaction.user.id)
            const embed = new Discord.EmbedBuilder()
            .setColor(config.cor)
            .setAuthor({ name: `${interaction.guild.name} - Atendimento`, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            .addFields(
            { name: ' > Quem Abriu:', value: ` ${interaction.user}`},
            { name: ' > Categoria do Ticket:', value: `\`\`\`Dúvidas\`\`\``}
            )
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setTimestamp()
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            
            let assumir = new Discord.ButtonBuilder()
            .setCustomId("assumido")
            .setLabel("Iniciar Atendimento")
            .setStyle(Discord.ButtonStyle.Primary)
            let row = new Discord.ActionRowBuilder().addComponents(assumir);
            
            ch.send({ embeds: [embed], components: [row] });
            });
        }

      } else if (opc === "opc2") {
        let nome = `📩・${interaction.user.username}`;
        if (interaction.guild.channels.cache.find(c => c.name === nome)) {
          interaction.reply({ content: `❌ Você já possui um ticket aberto em ${interaction.guild.channels.cache.find(c => c.name === nome)}!`, ephemeral: true })
        } else {
          interaction.guild.channels.create({
            name: nome,
            type: Discord.ChannelType.GuildText,
            parent: '1199871663605551155',
            permissionOverwrites: [
              {
                id: interaction.guild.id,
                deny: [
                  Discord.PermissionFlagsBits.ViewChannel
                ]

              },
              {
                id: interaction.user.id,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]

              },
              {
                id:  config.cargo_ticket,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]
              }
            ]
          }).then(async (ch) => {
            const ir = new Discord.ButtonBuilder()
            .setEmoji('🔗')
            .setLabel('Ir Para o Ticket')
            .setStyle(5)
            .setURL(`https://discord.com/channels/${interaction.guild.id}/${ch.id}`);

          const linkqn = new Discord.ActionRowBuilder().addComponents(ir);

          interaction.reply({ components: [linkqn], content: `${interaction.user} Para Acessar seu Ticket Basta Clicar Abaixo`, ephemeral: true});
          setTimeout(() => { interaction.deleteReply(); }, 7000);  
          await db.set(`quemabriu_${interaction.guild.id}`, interaction.user.id)
            let embed = new Discord.EmbedBuilder()
            .setColor(config.cor)
            .setAuthor({ name: `${interaction.guild.name} - Atendimento`, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            .addFields(
              { name: ' > Quem Abriu:', value: ` ${interaction.user}`},
            { name: '> Categoria do Ticket:', value: `\`\`\`Resgatar Produto\`\`\``}
            )
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setTimestamp()
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            
            let assumir = new Discord.ButtonBuilder()
            .setCustomId("assumido")
            .setLabel("Iniciar Atendimento")
            .setStyle(Discord.ButtonStyle.Primary)
            let row = new Discord.ActionRowBuilder().addComponents(assumir);

            ch.send({ embeds: [embed], components: [row], content: `|| @everyone - ${interaction.user} || ` })
          })
        }

      } else if (opc === "opc3") {
        let nome = `📩・${interaction.user.username}`;


        if (interaction.guild.channels.cache.find(c => c.name === nome)) {
          interaction.reply({ content: `❌ Você já possui um ticket aberto em ${interaction.guild.channels.cache.find(c => c.name === nome)}!`, ephemeral: true })
        } else {
          interaction.guild.channels.create({
            name: nome,
            type: Discord.ChannelType.GuildText,
            parent: '1199871663605551155',
            permissionOverwrites: [
              {
                id: interaction.guild.id,
                deny: [
                  Discord.PermissionFlagsBits.ViewChannel
                ]

              },
              {
                id: interaction.user.id,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]

              },
              {
                id:  config.cargo_ticket,
                allow: [
                  Discord.PermissionFlagsBits.ViewChannel,
                  Discord.PermissionFlagsBits.AttachFiles,
                  Discord.PermissionFlagsBits.EmbedLinks,
                  Discord.PermissionFlagsBits.AddReactions
                ]
              }
            ]
          }).then(async (ch) => {
            const ir = new Discord.ButtonBuilder()
            .setEmoji('🔗')
            .setLabel('Ir Para o Ticket')
            .setStyle(5)
            .setURL(`https://discord.com/channels/${interaction.guild.id}/${ch.id}`);

          const linkqn = new Discord.ActionRowBuilder().addComponents(ir);

          interaction.reply({ components: [linkqn], content: `${interaction.user} Para Acessar seu Ticket Basta Clicar Abaixo`, ephemeral: true});
          setTimeout(() => { interaction.deleteReply(); }, 7000);   
          await db.set(`quemabriu_${interaction.guild.id}`, interaction.user.id)
            const embed = new Discord.EmbedBuilder()
             .setColor(config.cor)
            .setAuthor({ name: `${interaction.guild.name} - Atendimento`, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            .addFields(
            { name: ' > Quem Abriu:', value: ` ${interaction.user}`},
            { name: '> Categoria do Ticket:', value: `\`\`\`Suporte\`\`\``}
            )
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setTimestamp()
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            
            let assumir = new Discord.ButtonBuilder()
            .setCustomId("assumido")
            .setLabel("Iniciar Atendimento")
            .setStyle(Discord.ButtonStyle.Primary)
            let row = new Discord.ActionRowBuilder().addComponents(assumir);

            ch.send({ embeds: [embed], components: [row], content: `|| @everyone - ${interaction.user} || ` })
          })
        }}
      }}
    });

////////////////////
//                                                             FUNÇÕES TICKET
////////////////////

client.on("interactionCreate", async (interaction) => {
  if (interaction.isButton()) {
      if (interaction.customId === "assumido") {
          if (interaction.member.roles.cache.has(config.cargo_ticket)) {
             const usuario = await db.get(`quemabriu_${interaction.guild.id}`)
             
            const embed_2 = new Discord.EmbedBuilder()
            .setColor(config.cor)
            .setAuthor({ name: `${interaction.guild.name} - Atendimento`, iconURL: interaction.guild.iconURL({ dynamic: true}) })
            .addFields(
              { name: ' > Usuario:', value: `<@${usuario}>`, inline: false},
              { name: ' > Assumido Por:', value: `${interaction.user}`, inline: false}
            )
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true}) });
              const opcaos1 = new Discord.ActionRowBuilder().addComponents(
                  new Discord.SelectMenuBuilder()
                      .setCustomId("opcaos")
                      .setPlaceholder("Escolha Uma Opção")
                      .addOptions(
                          {
                              label: "Notificar Membro",
                              description: "Clique aqui para notificar o membro.",
                              value: "opc5"
                          },
                          {
                            label: "Criar Call",
                            description: "Clique aqui para criar call.",
                            value: "opc7"
                        },
                          {
                              label: "Deletar Ticket",
                              description: "Clique aqui para encerrar esse ticket.",
                              value: "opc6"
                          }
                      )
              );
              interaction.update({ components: [opcaos1], embeds: [embed_2] });

          }
      }
  }
  if (interaction.isSelectMenu()) {
    if (interaction.customId === "opcaos") {
        let opc = interaction.values[0];
        if (opc === "opc5") {
          if (interaction.member.roles.cache.has(config.cargo_ticket)) {
            interaction.reply(" Notificando Membro em 5 segundos...").then((reply) => {
              setTimeout(() => {
                reply.edit(" Notificando Membro 4 segundos...");
              }, 1000);
              setTimeout(() => {
                reply.edit(" Notificando Membro em 3 segundos...");
              }, 2000);
              setTimeout(() => {
                reply.edit(" Notificando Membro em 2 segundos...");
              }, 3000);
              setTimeout(() => {
                reply.edit(" Membro Notificado Com Sucesso...");
              }, 4000);
              setTimeout(async () => {
                const notfy = await db.get(`quemabriu_${interaction.guild.id}`)
                const user = interaction.guild.members.cache.get(notfy)
                    const irt = new Discord.ButtonBuilder()
                    .setLabel("Ir Para Ticket")
                    .setURL(interaction.channel.url)
                    .setStyle("Link")
                    let row = new Discord.ActionRowBuilder().addComponents(irt);
                user.send({content: `# Estamos Aguardando Você Em Seu Ticket Aberto`, components: [row]})
              }, 5000);
            });
          }
      }

        if (opc === "opc6" && interaction.member.roles.cache.has(config.cargo_ticket)) {
          interaction.reply(" Deletando em 5 segundos...").then((reply) => {
              const delayMessages = [
                  "Deletando em 4 segundos...",
                  "Deletando em 3 segundos...",
                  "Deletando em 2 segundos...",
                  "Ticket Deletado Com Sucesso..."
              ];
      
              delayMessages.forEach((message, index) => {
                  setTimeout(() => {
                      reply.edit(` ${message}`);
                  }, (index + 1) * 1000);
              });
      
              setTimeout(async () => {
                const canalTranscript = interaction.channel;
        
                    const attachment = await transcript.createTranscript(canalTranscript, {
                        limit: -1,
                        returnType: 'attachment',
                        filename: `logs.html`,
                        saveImages: true,
                        footerText: ' Logs -  {number} mensagen{s}!',
                        poweredBy: false
                    });
        
                    interaction.channel.delete().catch((error) => {
                        console.error(`Erro ao deletar canal de ticket: ${error}`);
                    });
                    const usuario = await db.get(`quemabriu_${interaction.guild.id}`)
                    const user = interaction.guild.members.cache.get(usuario)
                    const logs_embed = new Discord.EmbedBuilder()
                        .setAuthor({ name: `${interaction.guild.name} Logs `, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                        .addFields(
                            { name: '**<:1137910226041978900Copia:1205218705571577998> Aberto Por:**', value: `${user}`, inline: true },
                            { name: '**<:vendiha_Staff:1199889044432236574> Finalizado Por:**', value: `${interaction.user}`, inline: true },
                        )
                        .setThumbnail(`${interaction.guild.iconURL({ dynamic: true })}`)
                        .setColor(config.cor)
                        .setTimestamp()
                        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) });
                        const ban = new Discord.ButtonBuilder()
                        .setLabel("Vendinha 🛒 #20K")
                        .setDisabled(true)
                        .setCustomId('ban')
                        .setStyle("Primary")
                        let row = new Discord.ActionRowBuilder().addComponents(ban);     
                    user.send({ embeds: [logs_embed], files: [attachment], components: [row] })
                    interaction.guild.channels.cache.get('1205360716417081355').send({ embeds: [logs_embed], components: [row] , files: [attachment] });
                  interaction.channel.delete()
                  const emoji = "📞";
                  interaction.guild.channels.cache.forEach((channel) => {
                      if (channel.type === 2 && channel.name.includes(emoji)) {
                          channel.delete().catch((error) => {
                              console.error(`Erro ao deletar canal de voz: ${error}`);
                          });
                      }
                  });
              }, 3000);
          });
      }
    }
  }  
if (interaction.customId === "opcaos") {
  let opc = interaction.values[0];
  if (opc === "opc7") {
    const channel_find = interaction.guild.channels.cache.find(c => c.name === `📞-${interaction.user.username.toLowerCase().replace(/ /g, '-')}`);

    if (channel_find) {
      return interaction.reply({
        embeds: [
          new Discord.EmbedBuilder()
             .setColor(config.cor)
            .setDescription(`❌ - Você já possui uma call aberta em ${channel_find}`)
        ],
        components: [
          new Discord.ActionRowBuilder()
            .addComponents(
              new Discord.ButtonBuilder()
                .setStyle(5)
                .setLabel('Entrar na call')
                .setURL(channel_find.url)
            )
        ],
        ephemeral: true
      });
    }
    setTimeout(() => { interaction.deleteReply(); }, 4000);


    const channel = await interaction.guild.channels.create({
      name: `📞-${interaction.user.username.toLowerCase().replace(/ /g, '-')}`,
      parent: '1199871286361456700',
      type: 2,
      permissionOverwrites: [
        {
          id: interaction.user.id,
          allow: ["Connect", "ViewChannel"],
        },
        {
          id: config.cargo_ticket,
          allow: ["Connect", "ViewChannel"],
        },
      ]
    });

    interaction.reply({
      embeds: [
        new Discord.EmbedBuilder()
           .setColor(config.cor)
          .setDescription(` ✅ - Call criada com sucesso em ${channel}`)
      ],
      components: [
        new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.ButtonBuilder()
              .setStyle(5)
              .setLabel('Entrar na call')
              .setURL(channel.url)
          )
      ],
      ephemeral: true,
    });
    setTimeout(() => { interaction.deleteReply(); }, 7000);
}
}
});
////////////////////
//                                                                 ANTI ERRO - NÃO RETIRE
////////////////

process.on('unhandRejection', (reason, promise) => {
    console.log(`🚫 Erro Detectado:\n\n` + reason, promise)
});
process.on('uncaughtException', (error, origin) => {
    console.log(`🚫 Erro Detectado:\n\n` + error, origin)
});